# F20 good prior save: a complete synthetic content candidate

The earlier bottleneck mixed two cases: a newly written shipped-format payload that omits history, and already-stored content with explicitly defined history. A complete synthetic already-stored candidate can be assessed without declaring a missing count to mean zero or pretending it was captured from a release.

This is a premise proposal for independent criterion review, not an accepted good-save witness or a new execution. It changes no save format in production and makes no ordinary capture, historical release or full F20 claim.

## The proposed content

prior-save.json is exact synthetic raw JSON. It describes a dense empty20x10 board, score0, canonical O at box(0,4), three O upcoming kinds, heldnone, Hold available and empty bag. Its explicit auditPersistedSemanticsV1 record fixes restoration modepaused, greatest occupied lowestrow1 and resetcount0. The record's format label expressly says synthetic-complete-not-released.

The independent decoder is declared before any fault: empty cells denote empty, yellow canonical piece definitions denote O, coordinates and score have their literal integer meaning, and the explicit history record denotes lowest1/count0. It rejects missing/different history rather than defaulting it. It is not the shipped parser, and a parser pass is not its expected validity.

When interpreted this way and restored paused, the current O occupies(0,4),(0,5),(1,4),(1,5), can descend, has lowest1/count0, and idle controls/no timers are required. No confirmation/drag/held controls are present in the declared restoration adapter; item16 is not persisted and is false at session start under S9. Missing or different auxiliary history rejects; it is never defaulted. B15 does not require a bag-dealing history for the O/O/O queue. The payload's explicit history prevents the missing-field ambiguity of the retained shipped saves.

## Applicability question to review

Blueprint O4's content definition includes already-stored saves that encode valid persisted state, independent of parser acceptance. S6 separately treats a successfully written valid save as good even if its step later faults. S11 permits hand-edited persisted content judged by whole R1 validity, without a legal-play-history requirement. These are existing recorded criteria, not authority to introduce a production format or weaken exact history.

For the already-stored case, the planned fixture must separately record an exact successful write before engine construction and before the selected fault. It would not be a successful saveGameSession capture. This candidate therefore asks for a narrow criterion judgment: whether this explicitly complete synthetic already-stored representation is admissible as independent good prior content for a scoped preservation test. No release-format compatibility is asserted.

Unknown-representation acceptance remains unresolved in the recorded method-support relation. This synthetic format is not established as a format the engine must support. Its test outcome is preservation of the declared synthetic prior, not an S11 whole-acceptance or STA6 compatibility finding, nor full F20 closure.

The released parser omits auditPersistedSemanticsV1. loadGameSession calls resetLockDelayForNewPiece, setting count0 and lowestRowReached to current.position.row, which is0, not the candidate's greatest occupied row1. Its actual restore does not preserve the candidate's fixed denotation. That is a separate correspondence result, not a reason to redefine the content from what the parser accepts. No claim is made here that a current shipped payload omitting those fields is good.

## Proposed next gate

Independently check the complete content/decoder and the already-stored S6/O4 applicability. If accepted, prepare a single predeclared fault-preservation fixture with raw bytes, successful preparation-write receipt, independent prior semantic decode and actual postfault payload/eligibility/resources. Choose a fault-stop trigger that does not intentionally withdraw or write a new save. Keep F20's write-order and current-writer claims separate.

If the criterion requires a production-origin save or rejects this auxiliary representation, record that exact reason rather than silently substituting a parser pass, zero-count default or asserted release history. This proposal supplies no such origin proof and cannot close broader F20.
