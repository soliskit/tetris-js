import pathlib,subprocess,hashlib
p=pathlib.Path('/tmp/tetris-f20-preservation')
for f in sorted((p/'public/game').glob('*.js')):
 rel=str(f.relative_to(p));orig=subprocess.check_output(['git','show','67d66398:'+rel],cwd='/tmp/tetris-queue-detector');copy=f.read_bytes();print(rel,hashlib.sha256(orig).hexdigest(),hashlib.sha256(copy).hexdigest(),'equal='+str(orig==copy));assert orig==copy
raw=(p/'prior-save.json').read_bytes();h=hashlib.sha256(raw).hexdigest();assert h=='15d48337cabd7e1dad841078bb450e65091bab8deb74a512929440f5904d2464';print('prior-save.json',len(raw),h,'expected_equal=True')
h=hashlib.sha256((p/'preservation.mjs').read_bytes()).hexdigest();assert h=='54dfb2218928154472221e3faba65aa028c1b076542e6b693c4d105efb34e56e';print('preservation.mjs',h,'reviewed_equal=True')
