import fs from 'node:fs';
import assert from 'node:assert/strict';
import {GameManager} from './public/game/gameManager.js';
import {PlayerAction} from './public/game/gameState.js';
const raw=fs.readFileSync(new URL('./prior-save.json',import.meta.url),'utf8');
const decode=text=>{const d=JSON.parse(text);const h=d.auditPersistedSemanticsV1;assert.deepEqual(h,{format:'synthetic-complete-not-released',modeOnRestore:'paused',lowestOccupiedRow:1,lockDelayResetCount:0});assert.equal(d.gameBoard.length,20);assert.ok(d.gameBoard.every(r=>r.length===10&&r.every(c=>c.isFilled===false&&c.color===null)));assert.equal(d.score,0);assert.deepEqual(d.currentTetromino.position,{row:0,column:4});assert.equal(d.currentTetromino.color,'#FFCC00');assert.deepEqual(d.currentTetromino.rotations,[[[true,true],[true,true]]]);assert.equal(d.currentTetromino.rotationState,0);assert.equal(d.nextTetrominos.length,3);assert.ok(d.nextTetrominos.every(p=>p.color==='#FFCC00'));assert.equal(d.heldTetromino,null);assert.equal(d.canHoldTetromino,true);assert.deepEqual(d.bag,[]);return {score:0,currentKind:'O',box:{row:0,column:4},occupied:[[0,4],[0,5],[1,4],[1,5]],lowest:1,count:0,restoreMode:'paused'};};
const prior=decode(raw);const events=[];const values=new Map();
const storage={getItem:k=>values.get(k)??null,setItem(k,v){const value=String(v);values.set(k,value);events.push({kind:'write',key:k,value});}};
// Preparation succeeds before constructing the engine, not via saveGameSession.
storage.setItem('tetris.savedGameSession',raw);storage.setItem('tetris.isSessionSaved','true');storage.setItem('tetris.highScore','0');
assert.equal(values.get('tetris.savedGameSession'),raw);const prepEnd=events.length;
const outstanding=new Map();const scheduler={setTimeout(){throw new Error('No registration expected in selected fault fixture');},clearTimeout(id){events.push({kind:'cancel',id:id??null,existed:outstanding.has(id)});outstanding.delete(id);}};
const faults=[];let changed=0;
const game=new GameManager({storage,scheduler,onFault:f=>{faults.push({reason:f.reason,error:String(f.error)});events.push({kind:'fault',reason:f.reason});},onChange:()=>{changed++;events.push({kind:'change'});}});
events.push({kind:'constructed'});const constructedIndex=events.length-1;
// Independent item16 session-start value, not a fabricated engine field.
const semanticWithdrawalAtStart=false;
// No saved-state load or intentional withdrawal: injected dependency refusal at action-read.
Object.defineProperty(game,'isConfirmingNewGame',{configurable:true,get(){throw new Error('selected confirmation-read refusal');}});
const actionBegin=events.length;game.handleAction(PlayerAction.rotate);
const post=decode(values.get('tetris.savedGameSession'));
assert.equal(values.get('tetris.savedGameSession'),raw);assert.equal(values.get('tetris.isSessionSaved'),'true');assert.ok(constructedIndex>=prepEnd);assert.equal(events.slice(actionBegin).filter(e=>e.kind==='write').length,0);assert.equal(game.state,'gameOver');assert.equal(game.gameLoopTask,null);assert.equal(game.lockDelayTask,null);assert.equal(outstanding.size,0);assert.equal(changed,1);assert.equal(faults.length,1);assert.equal(faults[0].reason,'unexpected error');assert.equal(semanticWithdrawalAtStart,false);
fs.writeFileSync(new URL('./preservation-result.json',import.meta.url),JSON.stringify({sourceCommit:'67d66398bee9cf2b5cc399f52c0e9526ae823fe3',scope:'one synthetic already-stored-prior, injected read refusal, no saved load/ordinary-history/native claim',prior,post,events,prepEnd,constructedIndex,actionBegin,final:{mode:game.state,gravity:game.gameLoopTask,lock:game.lockDelayTask,outstanding:outstanding.size,changed,faults,eligibility:values.get('tetris.isSessionSaved'),semanticWithdrawalAtStart},limits:['Unknown-format support not established or required by this packet','Not a current/released/game-written save','Decoder declared for this selected format only','Item16 semantic session-start value not a concrete correspondence theorem','Fault injection is a dependency getter refusal, not ordinary legal-play behavior','No native timers or saved-state acceptance/compatibility finding','Does not close F20 write ordering or all prior contents']},null,2)+'\n');
console.log('PASS: preparation preceded construction; one selected fault action retained exact synthetic prior and eligibility; no action storage writes.');
