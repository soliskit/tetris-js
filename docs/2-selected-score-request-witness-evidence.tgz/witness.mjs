import fs from 'node:fs';
import assert from 'node:assert/strict';
import {GameManager} from './public/game/gameManager.js';
import {GameState,PlayerAction} from './public/game/gameState.js';
import {allPieces,PieceColors} from './public/game/tetrominoFactory.js';
import {position} from './public/game/position.js';
const semantic=JSON.parse(fs.readFileSync(new URL('./semantic-snapshot.json',import.meta.url)));
const events=[];const outstanding=new Map();let next=1;
const number=v=>Number.isNaN(v)?'NaN':v;
const scheduler={setTimeout(callback,ms){const id=next++;outstanding.set(id,{callback,ms});events.push({kind:'register',id,ms:number(ms)});return id;},clearTimeout(id){events.push({kind:'cancel',id:id??null,existed:outstanding.has(id)});outstanding.delete(id);}};
const values=new Map([['tetris.highScore','0'],['tetris.isSessionSaved','false']]);
const storage={getItem(k){return values.get(k)??null;},setItem(k,v){const text=String(v);events.push({kind:'write',key:k,value:text});values.set(k,text);}};
const O=()=>allPieces()[1].copy();
const factory={bag:[],generate:()=>O(),resetBag(){this.bag=[];}};
const faults=[];let changed=0;
const game=new GameManager({scheduler,storage,factory,onFault:f=>{faults.push({reason:f.reason});events.push({kind:'fault',reason:f.reason});},onChange:()=>{changed++;events.push({kind:'change'});}});
// Deliberate scratch field injection from the independently reviewed semantic snapshot.
game.gameBoard=semantic.board.map(row=>row.map(kind=>kind===null?{isFilled:false,color:null}:{isFilled:true,color:PieceColors.cyan}));
game.currentTetromino=O();game.currentTetromino.position=position(0,4);game.nextTetrominos=[O(),O(),O()];game.heldTetromino=null;game.canHoldTetromino=true;game.score=0;game.state=GameState.playing;game.lockDelayResetCount=0;game.lowestRowReached=1;game.isConfirmingNewGame=false;
// This firing is declared outstanding but is never delivered. No native timer runs.
game.gameLoopTask=scheduler.setTimeout(()=>{throw new Error('Fixture must not deliver baseline gravity');},700);game.lockDelayTask=null;
const initial={score:game.score,state:game.state,outstanding:outstanding.size,monitor:game.findInvariantViolation(),fullRows:game.gameBoard.map((r,i)=>r.every(c=>c.isFilled)?i:null).filter(i=>i!==null)};
assert.equal(initial.monitor,null);assert.equal(initial.outstanding,1);assert.deepEqual(initial.fullRows,[15,16,17,18,19]);
events.length=0;
// Exactly one production public action. No retry, gameplay trace, CI or permanent-test mutation.
game.handleAction(PlayerAction.drop);
const final={score:number(game.score),state:game.state,gravityHandle:game.gameLoopTask,lockHandle:game.lockDelayTask,outstanding:outstanding.size,faults,changed,fullRows:game.gameBoard.map((r,i)=>r.every(c=>c.isFilled)?i:null).filter(i=>i!==null),filled:game.gameBoard.flatMap((row,r)=>row.flatMap((cell,c)=>cell.isFilled?[[r,c]]:[]))};
const requests=events.filter(e=>e.kind==='register');const payload=JSON.parse(values.get('tetris.savedGameSession')??'null');
assert.deepEqual(requests.map(r=>r.ms),['NaN']);
const payloadWrite=events.findIndex(e=>e.kind==='write'&&e.key==='tetris.savedGameSession');
const nanRegistration=events.findIndex(e=>e.kind==='register'&&e.ms==='NaN');
const faultEvent=events.findIndex(e=>e.kind==='fault');
const registeredId=requests[0].id;
const nanCancellation=events.findIndex(e=>e.kind==='cancel'&&e.id===registeredId&&e.existed);
assert.ok(payloadWrite>=0&&payloadWrite<nanRegistration&&nanRegistration<nanCancellation&&nanCancellation<faultEvent);
assert.equal(final.gravityHandle,null);assert.equal(final.lockHandle,null);assert.equal(final.changed,1);
assert.equal(payload.score,null);assert.equal(final.score,'NaN');assert.equal(final.state,GameState.gameOver);assert.equal(final.outstanding,0);assert.deepEqual(faults,[{reason:'score is invalid'}]);assert.deepEqual(final.filled,[[18,4],[18,5],[19,4],[19,5]]);assert.equal(values.get('tetris.isSessionSaved'),'true');
fs.writeFileSync(new URL('./witness-result.json',import.meta.url),JSON.stringify({sourceCommit:'67d66398bee9cf2b5cc399f52c0e9526ae823fe3',method:'single injected-snapshot Hard Drop with synthetic scheduler/storage; no callback delivery',initial,events,final,persisted:{score:payload.score,eligible:values.get('tetris.isSessionSaved')},limits:['Concrete controller fields not instantiated; semantic input controls declared idle','Item16 has no explicit concrete engine field; no full R1 correspondence claim','Ordinary legal-game reachability unestablished; parser rejects this board','No native timer conversion, delivery or physical gameplay','Success would reproduce only this injected source composition']},null,2)+'\n');
console.log('PASS: one injected Hard Drop, NaN gravity argument before score rejection, save score null, later successful cancellation.');
