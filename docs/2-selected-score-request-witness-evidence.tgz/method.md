# A concrete snapshot for the score/request ordering argument

Historical pre-execution geometry/admission packet. Its pending-execution language describes preparation before the later one-run witness; disposition.md and witness-result.json record the current execution outcome.

A dense board with five full bottom rows and a fitted O piece above them removes one conditional geometry gap in the published request-order map. A Hard Drop lands the O at box row13, clears exactly the five preexisting rows, and leaves room for the next O to spawn and move down. The next piece is not resting, so this selected generation step does not recursively lock another piece.

This is a proposed independent snapshot/admission packet for review. It is not a production execution, ordinary-play history, new finding or phase certificate. No game, test, CI or requirement change is included.

## Exact semantic input

`semantic-snapshot.json` declares all authoritative categories relevant to R1 and the required outstanding resources. Rows0..14 are empty, rows15..19 are full I-kind blocks. Current piece is O, rotation0, box(0,4), lowest occupied row1, resetcount0. Score0, empty bag, three O upcoming pieces, no held piece, Hold available. No confirmation, held control, repeat or drag. Withdrawal indicatorfalse. One outstanding gravity firing; no lock or repeat firing. Persisted eligibilityfalse, no saved payload and highscore0.

B3-B6 admit the dense board and fitted four-block piece. B7 allows the three upcoming kinds. B9.1 admits lowest1/count0. B10/B11 admit empty bag/score0. B12 admits idle controls and absent confirmation/drag. B13 requires gravity but no lock because the piece can descend. Amendment2 admits withdrawalfalse. B15 expressly does not prohibit full rows or impose bag-dealing history as snapshot predicates. These are checks against the recorded semantic definitions, not a pass from the shipped monitor.

A hypothetical current-piece history consisting of its appearance at this same position explains lowest1/count0. This does not supply a legal history for the whole board. No ordinary-game reachability is claimed, and the released parser rejects full rows, so accepted Continue cannot introduce this input.

## Independent geometry calculation

The calculation uses O offsets(0,0),(0,1),(1,0),(1,1) from the adopted geometry table, not production fits/dropDistance. The full row15 blocks descent to box14 because its lower pair would enter the full row15. Hard Drop therefore places cells(13,4),(13,5),(14,4),(14,5). The only full rows remain15..19. Removing them and adding five empty rows moves those O cells to rows18/19. The next O at box(0,4) fits and can move down, so there is no nested resting lock at that generation step.

`geometry-result.json` records this calculation. It is a fixture calculation, not a scheduler log or reproduction receipt.

## Concrete source adapter still to review

Fresh main67d66398bee9cf2b5cc399f52c0e9526ae823fe3 retains gameManager hash31bb2160852bd24485ba258c458b74acdec110c1e11b0d94f4f852f3cf27b9ea. A future scratch adapter would use the recorded O definitions, ordinary dense cell objects with canonical I color, a stable queue/factory providing O, ordinary storage, and a scheduler with one outstanding gravity firing. It must separately bind concrete controls, item16 absence/mapping, handle identity, serialization and source/checkpoint receipts. This packet does not silently call those source mappings proved.

Under that adapter's ordinary source premises, the five-row lookup yields undefined, so the engine score becomes NaN. The serializer has no validation predicate and JSON.stringify represents that score as null in the attempted payload. Generation then leaves playing with the non-resting O. Hard Drop reaches the fresh gravity request before the enclosing score check, as PR119 records. These are conditional source deductions, not observed writes or requests.

The complete implementation witness remains pending independent semantic/adapter review and permitted scratch execution. Safe-stop cancellation, native conversion/delivery, saved-content classification, S10 applicability and whole F22/PLY2/Phase4 remain separate.

## Criterion sources

Recorded R1 decision: docs/phase-1-r1-decision.md; Continue placement: docs/phase-1-d16-amendment-2.md; adopted O geometry: docs/sources/2-srs_table.txt. Source-order argument: docs/score-request-order-reconciliation.md. These records supply technical definitions for this analysis, not new action authority.
