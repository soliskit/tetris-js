import hashlib,pathlib,subprocess
p=pathlib.Path('/tmp/tetris-selected-request-witness')
for f in sorted((p/'public/game').glob('*.js')):
 rel=str(f.relative_to(p));original=subprocess.check_output(['git','show','67d66398bee9cf2b5cc399f52c0e9526ae823fe3:'+rel],cwd='/tmp/tetris-queue-detector');actual=f.read_bytes()
 print(rel,'main_sha256='+hashlib.sha256(original).hexdigest(),'copy_sha256='+hashlib.sha256(actual).hexdigest(),'byte_equal='+str(actual==original))
 assert actual==original
